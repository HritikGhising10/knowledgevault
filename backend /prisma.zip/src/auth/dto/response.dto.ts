export interface ResponseDTO {
    code: number;
    message: string;
    data?: any;
} 