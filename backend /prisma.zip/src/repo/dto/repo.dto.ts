export interface createRepoDTO {
    reponame: any;
    description: string;
    language: string;
}