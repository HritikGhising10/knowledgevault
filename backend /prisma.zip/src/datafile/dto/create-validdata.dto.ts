

export class CreateValidDataDto {
    validData: string;

    validDataDesc: string;
    archive?: boolean = false;

}