-- AlterTable
ALTER TABLE "Files" ADD COLUMN     "description" TEXT;
