/*
  Warnings:

  - You are about to drop the column `url` on the `Repository` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "Repository" DROP COLUMN "url";
