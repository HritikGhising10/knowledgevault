-- AlterTable
ALTER TABLE "Repository" ADD COLUMN     "documentation" TEXT;
